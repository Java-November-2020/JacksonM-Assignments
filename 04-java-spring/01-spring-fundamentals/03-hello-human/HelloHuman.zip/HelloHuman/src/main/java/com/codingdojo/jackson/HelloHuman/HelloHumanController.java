package com.codingdojo.jackson.HelloHuman;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class HelloHumanController {
	
	
	@RequestMapping("/")
	public String name(@RequestParam(value ="name", required=false) String name1, Model model) {
		model.addAttribute("name", name1);
		System.out.println(name1);
		if(name1 == null) {
			return "human.jsp";
		}
		else {
			return "index.jsp";
		}
//		System.out.println(name1);
//		return "index.jsp"; 
	}
	
}
